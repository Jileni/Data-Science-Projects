library("tm")
library("NLP")
library("wordcloud")
library("RColorBrewer")
library(SnowballC)
dt = readLines("C:/Users/Jileni/Desktop/DataScience/AdvancedLearning/TP1/apple.txt")
monCorpus <- Corpus(VectorSource(dt))
inspect(monCorpus)
summary(monCorpus)
#transformation
writeLines(as.character(monCorpus))
text_transform <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
monCorpus <- tm_map(monCorpus, text_transform, "/")
monCorpus <- tm_map(monCorpus, text_transform, "@")
monCorpus <- tm_map(monCorpus, text_transform, "\\|")

#netoyage
monCorpus <- tm_map(monCorpus, removeNumbers) 
monCorpus <- tm_map(monCorpus,removePunctuation)   
monCorpus <- tm_map(monCorpus,stripWhitespace)
monCorpus <- tm_map(monCorpus,tolower)
monCorpus <- tm_map(monCorpus,stripWhitespace)
monCorpus <- tm_map(monCorpus, removeWords, stopwords("english"))

# convertir le texte en minuscule
monCorpus <- tm_map(monCorpus, content_transformer(tolower))
# Supprimer les chiffres
monCorpus <- tm_map(monCorpus, removeNumbers)
# supprimer les stopwords (dictionnaire anglais)
monCorpus <- tm_map(monCorpus, removeWords, stopwords("english"))
# supprimer les ponctuations
monCorpus <- tm_map(monCorpus, removePunctuation)
# Text stemming : #
monCorpus <- tm_map(monCorpus, stemDocument)
monCorpus <- tm_map(monCorpus, removeWords, c("appl", "http"))

inspect(monCorpus)

dtm <- DocumentTermMatrix(monCorpus)   
inspect(dtm) 
tdm <- TermDocumentMatrix(monCorpus)   
inspect(tdm)
m <- as.matrix(tdm)
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
head(d,5)
#inspect(dtm[idx+(0:5), 101:110])
barplot(d[1:10,]$freq, las = 2, names.arg = d[1:10,]$word,
        col ="lightblue", main ="Most frequent words",
        ylab = "Word frequencies")
library(ggplot2)
p <- ggplot(subset(d, freq>50), aes(x = reorder(word, -freq), y = freq)) +
  geom_bar(stat = "identity") + 
  theme(axis.text.x=element_text(angle=45, hjust=1))
p
freq_terms <- sort(rowSums(m),decreasing=TRUE)
freq_terms <- subset(freq_terms, freq_terms >= 20)
ggplot(d, aes(x = word, y = freq)) + geom_bar(stat = "identity") +
  xlab("Terms") + ylab("Count") + coord_flip()
inspect(dtm)
findAssocs(dtm, "appl", corlimit=0.7)    
set.seed(142)   
wordcloud(names(freq_terms), freq_terms, min.freq_terms=100)   
set.seed(142)   
dark2 <- brewer.pal(6, "Dark2")   
wordcloud(names(freq_terms), freq_terms, max.words=25, rot.per=0.2, colors=dark2)   
dtmss <- removeSparseTerms(tdm, 0.2) # This makes a matrix that is only 15% empty space, maximum.   
dtmss
